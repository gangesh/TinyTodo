<?php
$config = array();
$config['db'] = 'mysql';
$config['mysql.host'] = 'localhost';
$config['mysql.db'] = 'tinytodo';
$config['mysql.user'] = 'root';
$config['mysql.password'] = '';
$config['prefix'] = 'tt_';
$config['url'] = '';
$config['mtt_url'] = '';
$config['title'] = '';
$config['lang'] = 'en';
$config['password'] = 'admin';
$config['smartsyntax'] = 0;
$config['timezone'] = 'Asia/Kolkata';
$config['autotag'] = 0;
$config['duedateformat'] = 1;
$config['firstdayofweek'] = 0;
$config['session'] = 'files';
$config['clock'] = 24;
$config['dateformat'] = '';
$config['dateformat2'] = '';
$config['dateformatshort'] = '';
$config['template'] = 'default';
$config['showdate'] = 0;
?>